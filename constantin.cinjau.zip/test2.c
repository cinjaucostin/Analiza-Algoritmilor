#include "utils.h"

int main()
{
    for (int i = 1; i <= NR_OF_TESTS; i++)
    {
        int m = 0;
        int *n = calloc(1, sizeof(int)), *sequence, *sequence_of_primes;

        char *input_filename = create_input_filename(i);
        char *output_filename = create_output_filename(i);
        FILE *fin = fopen(input_filename, "r");
        FILE *fout = fopen(output_filename, "w");
        if (fin == NULL || fout == NULL)
        {
            printf("ERROR! can't open file\n");
            exit(1);
        }

        sequence = read_from_input_file(fin, n);

        sequence_of_primes = calloc((*n) + 1, sizeof(int));
        for (int i = 0; i < (*n); i++)
        {
            int k = rand() % 100 + 90;
            if (isPrimeWithFermat(*(sequence + i), k) == 1)
            {
                *(sequence_of_primes + m) = *(sequence + i);
                m++;
            }
        }

        write_in_output_file(fout, sequence_of_primes, m);

        fclose(fin);
        free(n);
        free(sequence);
        free(input_filename);
        free(output_filename);
    }
    return 0;
}