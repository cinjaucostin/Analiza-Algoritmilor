#include "utils.h"

int main()
{
    for (int i = 1; i <= NR_OF_TESTS; i++)
    {
        int m = 0;
        int *n = calloc(1, sizeof(int)), *sequence, *sequence_of_primes;

        /*
            Partea de deschidere a fisierelor de input si output.
        */
        char *input_filename = create_input_filename(i);
        char *output_filename = create_output_filename(i);
        FILE *fin = fopen(input_filename, "r");
        FILE *fout = fopen(output_filename, "w");
        /*
            Daca nu s-a putut deschide unul dintre fisierele de intrare sau iesire programul se opreste
        */
        if (fin == NULL || fout == NULL)
        {
            printf("ERROR! opening file\n");
            exit(1);
        }

        /*
            Citirea datelor din fisierul de input.
        */
        sequence = read_from_input_file(fin, n);

        sequence_of_primes = calloc((*n) + 1, sizeof(int));
        for (int i = 0; i < (*n); i++)
        {
            /*
                Aceasta parte de implementare poate fi modificata pentru etapa urmatoare astfel incat sa putem face niste comparatii
            cat mai precise intre cei doi algoritmi, pentru un numar de iteratii fixat.
            */
            int k = rand() % 100 + 90;
            if (isPrimeWithMillerRabin(*(sequence + i), k) == 1)
            {
                *(sequence_of_primes + m) = *(sequence + i);
                m++;
            }
        }
        
        /*
            Scriere rezultatului in fisierul de output.
        */
        write_in_output_file(fout, sequence_of_primes, m);

        /*
            Inchiderea fisierelor folosite si eliberarea memoriei ocupate.
        */
        fclose(fin);
        free(n);
        free(sequence);
        free(input_filename);
        free(output_filename);
    }
    return 0;
}